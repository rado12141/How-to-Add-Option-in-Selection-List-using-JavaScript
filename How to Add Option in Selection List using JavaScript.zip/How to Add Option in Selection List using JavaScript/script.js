function addSelectList(){
	let select = document.getElementById('select');
	let option = document.getElementById('option');
	
	if(option.value == ""){
		alert("Required Field!");
	}else{
		let newOption = document.createElement("option");
		let newOptionValue = document.createTextNode(option.value);
		
		newOption.appendChild(newOptionValue);
		select.insertBefore(newOption, select.lastChildNode);
		
		option.value = "";
		select.value = "";
	}
}